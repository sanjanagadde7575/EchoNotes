package com.example.echonotes

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

const val CHANNEL_ID = "echo_notes_reminders"
const val ACTION_SNOOZE = "com.example.echonotes.ACTION_SNOOZE"
const val ACTION_MARK_DONE = "com.example.echonotes.ACTION_MARK_DONE"
const val EXTRA_NOTE_ID = "extra_note_id"

fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Echo Notes Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Reminders for your Echo Notes tasks"
        }
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }
}

fun showReminderNotification(context: Context, note: Note) {
    val snoozeIntent = Intent(context, NoteActionReceiver::class.java).apply {
        action = ACTION_SNOOZE
        putExtra(EXTRA_NOTE_ID, note.id)
    }
    val snoozePendingIntent = PendingIntent.getBroadcast(
        context, note.id * 10 + 1, snoozeIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val doneIntent = Intent(context, NoteActionReceiver::class.java).apply {
        action = ACTION_MARK_DONE
        putExtra(EXTRA_NOTE_ID, note.id)
    }
    val donePendingIntent = PendingIntent.getBroadcast(
        context, note.id * 10 + 2, doneIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val builder = NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_popup_reminder)
        .setContentTitle("Echo Notes reminder")
        .setContentText(note.text)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .addAction(0, "Snooze", snoozePendingIntent)
        .addAction(0, "Mark Done", donePendingIntent)

    val hasPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    if (hasPermission) {
        NotificationManagerCompat.from(context).notify(note.id, builder.build())
    }
}

