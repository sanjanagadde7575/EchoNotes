package com.example.echonotes

data class Note(
    val id: Int,
    val text: String,
    val category: String,
    val dueLabel: String,
    val isDone: Boolean = false,
    val isUrgent: Boolean = false
)