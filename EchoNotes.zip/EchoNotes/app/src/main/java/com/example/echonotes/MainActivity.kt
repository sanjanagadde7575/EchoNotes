package com.example.echonotes

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.echonotes.ui.theme.*
import java.util.Locale

val sampleNotes = mutableStateListOf(
    Note(1, "Call the dentist to reschedule appointment", "Personal", "Today, 10:00 AM", isUrgent = true),
    Note(2, "Pick up dry cleaning", "Home", "Tomorrow, 5:00 PM"),
    Note(3, "Pay electricity bill", "Payments", "Fri, 9:00 AM"),
    Note(4, "Book club meeting notes", "Personal", "Next week"),
    Note(5, "Send expense report", "Work", "Done", isDone = true)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        setContent {
            MaterialTheme {
                val notificationPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { }
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        containerColor = Cream,
        bottomBar = {
            if (currentRoute == "home" || currentRoute == "insights") {
                NavigationBar(containerColor = CardWhite) {
                    NavigationBarItem(
                        selected = currentRoute == "home",
                        onClick = {
                            navController.navigate("home") {
                                popUpTo("home") { inclusive = true }
                            }
                        },
                        icon = { Icon(Icons.Filled.List, contentDescription = "Notes") },
                        label = { Text("Notes") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "insights",
                        onClick = {
                            navController.navigate("insights") {
                                popUpTo("home")
                            }
                        },
                        icon = { Icon(Icons.Filled.BarChart, contentDescription = "Insights") },
                        label = { Text("Insights") }
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentRoute == "home") {
                FloatingActionButton(onClick = { navController.navigate("voice") }, containerColor = Accent) {
                    Icon(Icons.Filled.Mic, contentDescription = "Record a voice note")
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeContent() }
            composable("insights") { InsightsScreen() }
            composable("voice") {
                VoiceScreen(
                    onBack = { navController.popBackStack() },
                    onSave = { navController.popBackStack() }
                )
            }
        }
    }
}

fun detectCategory(text: String): String {
    val lower = text.lowercase()
    return when {
        listOf("work", "meeting", "office", "report", "email", "project").any { lower.contains(it) } -> "Work"
        listOf("bill", "pay", "rent", "invoice", "payment").any { lower.contains(it) } -> "Payments"
        listOf("clean", "home", "grocery", "laundry", "dishes", "kitchen").any { lower.contains(it) } -> "Home"
        else -> "Personal"
    }
}

fun detectDueLabel(text: String): String {
    val regex = Regex("""(\d{1,2}(:\d{2})?\s*(a\.?m\.?|p\.?m\.?))""", RegexOption.IGNORE_CASE)
    val match = regex.find(text)
    return if (match != null) {
        "Today, " + match.value.uppercase().replace(".", "")
    } else {
        "No time detected"
    }
}

fun detectUrgency(text: String): Boolean {
    val lower = text.lowercase()
    return listOf("urgent", "asap", "important", "emergency", "immediately").any { lower.contains(it) }
}

@Composable
fun HomeContent() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Echo Notes", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn {
            items(sampleNotes) { note ->
                NoteCard(note)
            }
        }
    }
}

@Composable
fun InsightsScreen() {
    val total = sampleNotes.size
    val completed = sampleNotes.count { it.isDone }
    val urgent = sampleNotes.count { it.isUrgent }

    val categories = listOf("Work", "Personal", "Home", "Payments")
    val categoryCounts = categories.associateWith { cat -> sampleNotes.count { it.category == cat } }
    val maxCount = (categoryCounts.values.maxOrNull() ?: 0).coerceAtLeast(1)

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text("Insights", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        Spacer(modifier = Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Total", total.toString(), Modifier.weight(1f))
            StatTile("Completed", completed.toString(), Modifier.weight(1f))
            StatTile("Urgent", urgent.toString(), Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(28.dp))
        Text("Notes by category", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Spacer(modifier = Modifier.height(16.dp))

        categories.forEach { cat ->
            val count = categoryCounts[cat] ?: 0
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Text(cat, modifier = Modifier.width(80.dp), style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Box(modifier = Modifier.weight(1f).height(14.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction = count / maxCount.toFloat())
                            .fillMaxHeight()
                            .background(Accent, shape = RoundedCornerShape(999.dp))
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(count.toString(), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, color = Accent)
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
    }
}

@Composable
fun VoiceScreen(onBack: () -> Unit, onSave: () -> Unit) {
    var transcribedText by remember { mutableStateOf("") }
    val context = LocalContext.current

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val results = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            transcribedText = results?.getOrNull(0) ?: ""
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your task...")
            }
            speechLauncher.launch(intent)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🎤 Tap to speak your task", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { permissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO) }) {
            Text("Start Recording")
        }

        if (transcribedText.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text("You said:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
            Text(transcribedText, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)

            Spacer(modifier = Modifier.height(16.dp))
            Text("Category: ${detectCategory(transcribedText)}", style = MaterialTheme.typography.bodyMedium, color = Accent)
            Text("When: ${detectDueLabel(transcribedText)}", style = MaterialTheme.typography.bodyMedium, color = Accent)
            Text(
                "Urgency: ${if (detectUrgency(transcribedText)) "Urgent" else "Normal"}",
                style = MaterialTheme.typography.bodyMedium,
                color = if (detectUrgency(transcribedText)) Urgent else Accent
            )

            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = {
                val newNote = Note(
                    id = (sampleNotes.maxOfOrNull { it.id } ?: 0) + 1,
                    text = transcribedText.replaceFirstChar { it.uppercase() },
                    category = detectCategory(transcribedText),
                    dueLabel = detectDueLabel(transcribedText),
                    isUrgent = detectUrgency(transcribedText)
                )
                sampleNotes.add(0, newNote)
                showReminderNotification(context, newNote)
                updateAllWidgets(context)
                onSave()
            }) {
                Text("Save Note")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        Button(onClick = onBack) {
            Text("Back")
        }
    }
}

@Composable
fun NoteCard(note: Note) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(if (note.isUrgent) Urgent else Color.Transparent)
            )
            Column(modifier = Modifier.padding(16.dp).weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        note.text,
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    if (note.isUrgent) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(Urgent.copy(alpha = 0.15f), shape = RoundedCornerShape(999.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Urgent", style = MaterialTheme.typography.labelSmall, color = Urgent)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("${note.category} · ${note.dueLabel}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}