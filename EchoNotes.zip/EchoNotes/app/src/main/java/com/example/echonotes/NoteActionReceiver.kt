package com.example.echonotes

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class NoteActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val noteId = intent.getIntExtra(EXTRA_NOTE_ID, -1)
        if (noteId == -1) return

        when (intent.action) {
            ACTION_MARK_DONE -> {
                val index = sampleNotes.indexOfFirst { it.id == noteId }
                if (index != -1) {
                    sampleNotes[index] = sampleNotes[index].copy(isDone = true, dueLabel = "Done")
                }
                Toast.makeText(context, "Marked as done", Toast.LENGTH_SHORT).show()
            }
            ACTION_SNOOZE -> {
                Toast.makeText(context, "Snoozed for 1 minute", Toast.LENGTH_SHORT).show()
                val note = sampleNotes.find { it.id == noteId }
                if (note != null) {
                    Handler(context.mainLooper).postDelayed({
                        showReminderNotification(context, note)
                    }, 60_000L)
                }
            }
        }

        updateAllWidgets(context)
        NotificationManagerCompat.from(context).cancel(noteId)
    }
}