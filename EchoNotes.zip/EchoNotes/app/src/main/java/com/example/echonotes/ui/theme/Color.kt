package com.example.echonotes.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFFDF9F3)
val CardWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF2B2620)
val TextSecondary = Color(0xFF7C7468)
val TextTertiary = Color(0xFFA79F92)
val Accent = Color(0xFFF2994A)
val AccentStrong = Color(0xFFFFAD63)
val Urgent = Color(0xFFEF6F6C)
val Success = Color(0xFF3FAE7A)