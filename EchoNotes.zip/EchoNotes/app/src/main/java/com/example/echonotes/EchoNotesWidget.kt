package com.example.echonotes

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

class EchoNotesWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (widgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, widgetId)
        }
    }
}

fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, widgetId: Int) {
    val pending = sampleNotes.count { !it.isDone }
    val urgentCount = sampleNotes.count { it.isUrgent && !it.isDone }

    val views = RemoteViews(context.packageName, R.layout.widget_echo_notes)
    views.setTextViewText(R.id.widget_summary, "$pending tasks pending")
    views.setTextViewText(R.id.widget_urgent, if (urgentCount > 0) "$urgentCount urgent" else "")
    appWidgetManager.updateAppWidget(widgetId, views)
}

fun updateAllWidgets(context: Context) {
    val appWidgetManager = AppWidgetManager.getInstance(context)
    val componentName = ComponentName(context, EchoNotesWidget::class.java)
    val widgetIds = appWidgetManager.getAppWidgetIds(componentName)
    for (widgetId in widgetIds) {
        updateWidget(context, appWidgetManager, widgetId)
    }
}